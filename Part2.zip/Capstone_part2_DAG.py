from airflow import DAG
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.operators.python import PythonOperator
from datetime import datetime
from airflow.models import Variable 
import requests
import json
import pandas as pd
import boto3
import psycopg2




def save_json_to_file():
    file_path= '/mnt/c/dag/file'
    # Save the JSON data to a file
    
    url = "https://jsearch.p.rapidapi.com/search"
    querystring = {"query":"Data Engieer and Data Analyst in Cannada","page":"1","num_pages":"1","date_posted":"today"}
    headers = {
	"X-RapidAPI-Key": "1f21d68a3bmsh2e902bfcaacb348p1708fbjsnf74680ea618b",
	"X-RapidAPI-Host": "jsearch.p.rapidapi.com"
    }

    response = requests.get(url, headers=headers, params=querystring)
    response_json = response.json()
    raw_data= response_json['data']
    with open('/mnt/c/dag/json_data.json', 'w') as file:
        json.dump(raw_data, file)

  
    
def upload_raw_data_to_s3():
    s3_hook = S3Hook(aws_conn_id='aws_default')
    bucket_name = 'raw-jobs-data1'
    s3_hook.load_file(
        filename='/mnt/c/dag/json_data.json',
        key='raw_data.json',
        bucket_name=bucket_name,
        replace=True
    )
   
def prosessed_data():
    s3_hook = S3Hook(aws_conn_id='aws_default')
    bucket_name = 'processed-data-1'
    df=pd.read_json('/mnt/c/dag/json_data.json')
    required_col = ['employer_website', 'job_id', 'job_employment_type', 'job_title',
                          'job_apply_link', 'job_description', 'job_city', 'job_country',
                          'job_posted_at_timestamp', 'employer_company_type']
    
    df= df[required_col]
    df.to_csv('/mnt/c/dag/json_data.csv', index=False)
    s3_hook.load_file(
        filename='/mnt/c/dag/json_data.csv',
        key='processed_data.csv',
        bucket_name=bucket_name,
        replace=True
    )

def load_to_data_warehouse():
    #configure variables 
    s3_bucket = Variable.get("s3_bucket_transformed_data")
    s3_key = 'data_csv.csv'

    redshift_endpoint = '************'
    redshift_port = 5439
    redshift_db = 'dev'
    redshift_user = 'admin'
    redshift_password = Variable.get('redshift_password')
    redshift_table = 'job_data'

    # Initialize AWS clients
    #s3_hook = S3Hook(aws_conn_id='aws_s3')
    s3_client = boto3.client('s3')

    # Download the CSV file from S3

    local_file_path = '/tmp/file.csv'  # Path to store the file temporarilly
    s3_client.download_file(s3_bucket, s3_key, local_file_path)

    # establish a connection to redshift database
    redshift_conn = psycopg2.connect(
        host=redshift_endpoint,
        port=redshift_port,
        dbname=redshift_db,
        user=redshift_user,
        password=redshift_password
    )

    # create a cursor
    redshift_cursor = redshift_conn.cursor()

    # Load the CSV file into Redshift

    copy_query = f"COPY {redshift_table} FROM '{local_file_path}' CSV DELIMITER ',' IGNOREHEADER 1;"
    redshift_cursor.execute(copy_query)

    # close connection
    redshift_conn.commit()
    redshift_cursor.close()
    redshift_conn.close()


# dag call
with DAG('Job_search_dag', start_date=datetime(2023, 6, 17), schedule_interval='@daily') as dag:
    task1 = PythonOperator(
        task_id='save_json_to_file',
        python_callable=save_json_to_file
    )  
    task2=PythonOperator(
        task_id='upload_raw_data_to_s3',
        python_callable=upload_raw_data_to_s3
    ) 
    task3=PythonOperator(
        task_id='processed_data',
        python_callable=processed_data
    )


task1 >> task2 >> task3